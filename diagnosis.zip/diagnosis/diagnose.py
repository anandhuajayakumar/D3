from pyspark import SparkContext
from datetime import datetime
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
import json
from pyspark.sql import Row
from pyspark.sql import SparkSession, SQLContext
from pyspark.ml.linalg import Vectors
import MySQLdb

#To run this pyspark script, here is an example:
#$SPARK_HOME/bin/spark-submit --jars /Users/gramaswamy/Desktop/Programs/spark-jobs/kafka-streaming/spark-streaming-kafka-0-8-assembly_2.11-2.0.1.jar diagnose.py
#When saving to mysql use:
#$SPARK_HOME/bin/spark-submit --driver-class-path /Users/gramaswamy/Desktop/Programs/mysql/mysql-connector-java-5.1.39/mysql-connector-java-5.1.39-bin.jar --jars /Users/gramaswamy/Desktop/Programs/spark-jobs/kafka-streaming/spark-streaming-kafka-0-8-assembly_2.11-2.0.1.jar:/Users/gramaswamy/Desktop/Programs/mysql/mysql-connector-java-5.1.39/mysql-connector-java-5.1.39-bin.jar diagnose.py


if __name__ == "__main__":
    rootDir = "/Users/gramaswamy/Desktop/Programs/spark-jobs/machine_learning/heart-disease/"
    modelDir = "file://" + rootDir + "diagnosis_models/"
    runTime=datetime.strftime(datetime.now(), '%m-%d-%Y--%H-%M-%S')

    _appName="PythonStreamingKafkaPredictor"
    sc = SparkContext(appName=_appName)
    ssc = StreamingContext(sc, 10) #here 10 is in seconds
    SpSession = SparkSession(sc)
    sqlContext = SQLContext(sc)
        
    zkQuorum="localhost:2181"
    topic = "streamtopic"
    kafkaStream = KafkaUtils.createStream(ssc, zkQuorum, "spark-streaming-consumer", {topic: 1})
    rdds = kafkaStream
    kafkaStream.pprint
    def processRecord(rdd):
        try: 
            record = rdd.first() #If RDD is empty, this will throw an error
            print "Input record is: ",record 
            jsonstr=str(record[1])
            
            inputVars =json.loads(jsonstr)
            for each in inputVars:
                print each,"=",inputVars[each]
                
            
            #csvstr="%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s"%(\
            #             inputVars["age"],inputVars["gender"],inputVars["chestPain"],inputVars["restBp"],\
            #             inputVars["chol"],inputVars["fbs"],inputVars["restecg"],inputVars["thalach"],\
            #             inputVars["exang"],inputVars["stdepn"],inputVars["slope"],inputVars["vessels"],\
            #             inputVars["thal"]
            #             )
            line =[]
            line.append((inputVars["age"]))
            line.append((inputVars["gender"]))
            line.append((inputVars["chestPain"]))
            line.append((inputVars["restBp"]))
            line.append((inputVars["chol"]))
            line.append((inputVars["fbs"]))
            line.append((inputVars["restecg"]))
            line.append((inputVars["thalach"]))
            line.append((inputVars["exang"]))
            line.append((inputVars["stdepn"]))
            line.append((inputVars["slope"]))
            line.append((inputVars["vessels"]))
            line.append((inputVars["thal"]))
            
            points = sc.parallelize([line])
            print points.collect()
            parts = points
            
            #parts = points.map(lambda l: l.split(","))
            #print parts.collect()
            from pyspark.ml.linalg import Vectors      
            pointsMap = parts.map(lambda p: Row (AGE=float(inputVars["age"]),\
                                    SEX=float(inputVars["gender"]),\
                                    CHEST_PAIN_TYPE=float(inputVars["chestPain"]),\
                                    RESTING_BP=float(inputVars["restBp"]),\
                                    SERUM_CHOL=float(inputVars["chol"]),\
                                    FASTING_BLOOD_SUGAR=float(inputVars["fbs"]),\
                                    REST_ECG=float(inputVars["restecg"]),\
                                    MAX_HEARTRATE_ACHIEVED=float(inputVars["thalach"]),\
                                    EXERCISE_INDUCED_ANGINA=float(inputVars["exang"]),\
                                    ST_DEPRN_INDUCED_BY_EXERCISE=float(inputVars["stdepn"]),\
                                    SLOPE_PEAK_EXERCISE_ST=float(inputVars["slope"]),\
                                    NUM_MAJOR_VESSELS=float(inputVars["vessels"]),\
                                    THAL_OR_HEART_RATE=float(inputVars["thal"]) 
                                    ))  
                                            
            pointsDf = SpSession.createDataFrame(pointsMap)
            pointsDf.cache()
            print "pointsDf:\n ", pointsDf.show(truncate=False)
            
            print 'Number of rows to be processed: %s' % pointsDf.count()
            
            def transformToLabeledPoint(row) :
                lp = ( 0, \
                           Vectors.dense([row["AGE"],row["CHEST_PAIN_TYPE"],row["EXERCISE_INDUCED_ANGINA"],\
                            row["FASTING_BLOOD_SUGAR"],row["MAX_HEARTRATE_ACHIEVED"],row["NUM_MAJOR_VESSELS"],\
                            row["RESTING_BP"],row["REST_ECG"],row["SERUM_CHOL"],row["SEX"],row["SLOPE_PEAK_EXERCISE_ST"],\
                            row["ST_DEPRN_INDUCED_BY_EXERCISE"],row["THAL_OR_HEART_RATE"]]))
                return lp
                
            
                
            pointsLp = pointsDf.rdd.map(transformToLabeledPoint)
            print pointsLp
            
            pointsLpDf = SpSession.createDataFrame(pointsLp,["label", "features"])
            pointsLpDf.select("label","features").show(10, False)
            pointsLpDf.cache()
            
            from pyspark.ml.feature import StringIndexer
            stringIndexer = StringIndexer(inputCol="label", outputCol="indexed")
            si_model = stringIndexer.fit(pointsLpDf)
            td = si_model.transform(pointsLpDf)   
            
            rootDir = "/Users/gramaswamy/Desktop/Programs/spark-jobs/machine_learning/heart-disease/"
            modelDir = "file://" + rootDir + "diagnosis_models/"
               
            #from pyspark.ml.classification import DecisionTreeClassificationModel
            #model = DecisionTreeClassificationModel.load(modelDir + "decision_tree_model/")
            
            from pyspark.ml.classification import DecisionTreeClassificationModel
            model = DecisionTreeClassificationModel.load(modelDir + "decision_tree_model/")
            
            #Predict on the new data
            predictions = model.transform(td)
            print "Predictions:\n", predictions.show(10,False)
            predictionDf = predictions.select("prediction")
            predictedValue1 = int(predictionDf.first()[0])
            print "Predicted Value (using Decision Tree)=",predictedValue1
            
            from pyspark.ml.classification import RandomForestClassificationModel
            model = RandomForestClassificationModel.load(modelDir + "random_forest_model/")
            
            #Predict on the new data
            predictions = model.transform(td)
            print "Predictions:\n", predictions.show(10,False)
            predictionDf = predictions.select("prediction")
            predictedValue2 = int(predictionDf.first()[0])
            print "Predicted Value (using Random Forests)=",predictedValue2
            
            from pyspark.ml.classification import NaiveBayesModel
            model = NaiveBayesModel.load(modelDir + "naive_bayes_model/")
            
            #Predict on the new data
            predictions = model.transform(td)
            print "Predictions:\n", predictions.show(10,False)
            predictionDf = predictions.select("prediction")
            predictedValue3 = int(predictionDf.first()[0])
            print "Predicted Value (using Naive Bayes)=", predictedValue3           
            
            import numpy as np
            import math
            a=np.array([predictedValue1,predictedValue2,predictedValue3])
            
            if predictedValue1!=predictedValue2 and predictedValue1!=predictedValue3 \
                                                and predictedValue2!=predictedValue3:
                predictedValue= math.ceil(np.average(a))
            else: 
                counts=np.bincount(a)
                predictedValue = np.argmax(counts)
            print "Overall predicted value = ",predictedValue 
            
            #Save the result to a mysql table
            # Open database connection
            db = MySQLdb.connect("localhost","root","","medicaid" )            
            # prepare a cursor object using cursor() method
            cursor = db.cursor()            
            # Prepare SQL query to INSERT a record into the database.
            sql = """INSERT INTO DIAGNOSIS_RESULTS(RQID,PREDICTION,INPUTS,DIAGNOSIS_DATE)
                     VALUES ('%s', %f, '%s',SYSDATE())"""%(inputVars["rqid"],predictedValue,jsonstr)
            try:
               # Execute the SQL command
               cursor.execute(sql)
               # Commit your changes in the database
               db.commit()
            except:
               # Rollback in case there is any error
               db.rollback()            
            # disconnect from server
            db.close()  
            rdd.unpersist()
            pointsLpDf.unpersist()
            predictionDf.unpersist()
        except Exception,e:
            err =str(e)
            if "RDD is empty" in err: #print "Nothing to process. Empty RDD!"
                pass
            else:
                print err
        return 
             
    rdds.foreachRDD(lambda k: processRecord(k))
    
    #DStreams can be saved using: saveAsTextFiles("file://" + rootDir + "runs/result-"+runTime)
   
    ssc.start()
    ssc.awaitTermination()